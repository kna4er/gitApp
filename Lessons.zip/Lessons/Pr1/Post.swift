
import Foundation

struct Post: Decodable {
    
    let id: Int?
    let title: String?
    let body: String?
    
}
