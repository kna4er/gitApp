
import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var postTitle: UILabel!
    @IBOutlet var postBody: UITextView!
    
}
